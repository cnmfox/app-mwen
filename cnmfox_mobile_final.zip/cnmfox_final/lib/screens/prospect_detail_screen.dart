import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/prospect.dart';
import '../services/storage.dart';
import 'prospect_edit_screen.dart';

class ProspectDetailScreen extends StatelessWidget {
  final Prospect prospect;
  const ProspectDetailScreen({super.key, required this.prospect});

  Future<void> _launch(String url) async {
    final u = Uri.parse(url);
    if (await canLaunchUrl(u)) {
      await launchUrl(u, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _delete(BuildContext c) async {
    final ok = await showDialog<bool>(
        context: c,
        builder: (d) => AlertDialog(
              title: const Text('Efase pwospek sa?'),
              content: Text(prospect.name),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(d, false),
                    child: const Text('Anile')),
                FilledButton(
                    onPressed: () => Navigator.pop(d, true),
                    child: const Text('Efase')),
              ],
            ));
    if (ok != true) return;
    final all = await Storage.loadAll();
    all.removeWhere((x) => x.id == prospect.id);
    await Storage.saveAll(all);
    if (c.mounted) Navigator.pop(c);
  }

  @override
  Widget build(BuildContext c) {
    final p = prospect;
    return Scaffold(
      appBar: AppBar(title: Text(p.name), actions: [
        IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () => Navigator.push(
                    c,
                    MaterialPageRoute(
                        builder: (_) => ProspectEditScreen(prospect: p)))
                .then((_) {
              if (c.mounted) Navigator.pop(c);
            })),
        IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.red),
            onPressed: () => _delete(c)),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(
            child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _row(Icons.category, 'Kategori', p.category),
            _row(Icons.place, 'Adrès', p.address),
            _row(Icons.phone, 'Telefòn', p.phone,
                action: p.hasWhatsApp
                    ? () => _launch('https://wa.me/${p.waNumber}')
                    : null),
            _row(Icons.language, 'Sit wèb', p.website,
                action: p.hasWebsite
                    ? () => _launch(p.website.startsWith('http')
                        ? p.website
                        : 'https://${p.website}')
                    : null),
            _row(Icons.map, 'Google Maps', p.mapsUrl,
                action: p.mapsUrl.isNotEmpty ? () => _launch(p.mapsUrl) : null),
            _row(Icons.star, 'Rating', p.rating),
            _row(Icons.info, 'Estat', p.status),
            _row(Icons.card_giftcard, 'Pake', p.packageOffered),
            _row(Icons.attach_money, 'Valè', '\$${p.dealValue}'),
            _row(Icons.source, 'Sous', p.source),
            _row(Icons.note, 'Nòt', p.notes),
          ]),
        )),
      ]),
    );
  }

  Widget _row(IconData i, String label, String value, {VoidCallback? action}) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Icon(i, size: 20, color: Colors.grey),
          const SizedBox(width: 12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
            Text(value.isEmpty ? '—' : value),
          ])),
          if (action != null)
            IconButton(
                icon: const Icon(Icons.open_in_new, size: 18), onPressed: action),
        ]),
      );
}
