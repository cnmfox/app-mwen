import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/prospect.dart';
import '../services/storage.dart';
import 'prospect_detail_screen.dart';
import 'prospect_edit_screen.dart';

class ProspectListScreen extends StatefulWidget {
  const ProspectListScreen({super.key});
  @override
  State<ProspectListScreen> createState() => _ProspectListScreenState();
}

class _ProspectListScreenState extends State<ProspectListScreen> {
  List<Prospect> _all = [], _filtered = [];
  bool _loading = true;
  String _search = '';
  String _filter = 'all';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _all = await Storage.loadAll();
    _apply();
    if (mounted) setState(() => _loading = false);
  }

  void _apply() {
    var list = _all;
    if (_search.isNotEmpty) {
      final s = _search.toLowerCase();
      list = list
          .where((p) =>
              p.name.toLowerCase().contains(s) ||
              p.category.toLowerCase().contains(s) ||
              p.address.toLowerCase().contains(s) ||
              p.phone.contains(s))
          .toList();
    }
    switch (_filter) {
      case 'whatsapp':
        list = list.where((p) => p.hasWhatsApp).toList();
        break;
      case 'no_whatsapp':
        list = list.where((p) => !p.hasWhatsApp).toList();
        break;
      case 'website':
        list = list.where((p) => p.hasWebsite).toList();
        break;
      case 'no_website':
        list = list.where((p) => !p.hasWebsite).toList();
        break;
      case 'nouveau':
        list = list.where((p) => p.status == 'Nouvo').toList();
        break;
      case 'chal':
        list = list.where((p) => p.status == 'Chal').toList();
        break;
      case 'kliyan':
        list = list.where((p) => p.status == 'Kliyan').toList();
        break;
    }
    setState(() => _filtered = list);
  }

  Future<void> _openWhatsApp(Prospect p) async {
    final digits = p.waNumber;
    final url = Uri.parse('https://wa.me/$digits');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pwospek (${_filtered.length})'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(104),
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
              child: TextField(
                decoration: const InputDecoration(
                    hintText: 'Chèche non, adrès, telefon...',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                    isDense: true),
                onChanged: (v) {
                  _search = v;
                  _apply();
                },
              ),
            ),
            SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  children: [
                    _chip('Tout', 'all'),
                    _chip('📱 WA', 'whatsapp'),
                    _chip('❌ San WA', 'no_whatsapp'),
                    _chip('🌐 Sit', 'website'),
                    _chip('❌ San sit', 'no_website'),
                    _chip('Nouvo', 'nouveau'),
                    _chip('Chal', 'chal'),
                    _chip('Kliyan', 'kliyan'),
                  ],
                )),
            const SizedBox(height: 8),
          ]),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
                c,
                MaterialPageRoute(
                    builder: (_) => const ProspectEditScreen()))
            .then((_) => _load()),
        icon: const Icon(Icons.add),
        label: const Text('Ajoute'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _filtered.isEmpty
              ? const Center(child: Text('Pa gen biznis'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    itemCount: _filtered.length,
                    itemBuilder: (_, i) {
                      final p = _filtered[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 4),
                        child: ListTile(
                          title: Text(p.name,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                    '${p.category} • ${p.phone.isNotEmpty ? p.phone : "Pa gen nimewo"}',
                                    style: const TextStyle(fontSize: 12)),
                                Row(children: [
                                  if (p.hasWhatsApp)
                                    const Icon(Icons.phone,
                                        size: 14, color: Colors.green),
                                  if (p.hasWebsite)
                                    const Padding(
                                        padding: EdgeInsets.only(left: 6),
                                        child: Icon(Icons.language,
                                            size: 14, color: Colors.blue)),
                                  const SizedBox(width: 8),
                                  _statusBadge(p.status),
                                ]),
                              ]),
                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                            if (p.hasWhatsApp)
                              IconButton(
                                  icon: const Icon(Icons.chat,
                                      color: Colors.green),
                                  onPressed: () => _openWhatsApp(p)),
                            const Icon(Icons.chevron_right),
                          ]),
                          onTap: () => Navigator.push(
                              c,
                              MaterialPageRoute(
                                builder: (_) =>
                                    ProspectDetailScreen(prospect: p),
                              )).then((_) => _load()),
                        ),
                      );
                    },
                  ),
                ),
    );
  }

  Widget _chip(String label, String v) => Padding(
        padding: const EdgeInsets.only(right: 6),
        child: FilterChip(
          label: Text(label, style: const TextStyle(fontSize: 12)),
          selected: _filter == v,
          onSelected: (_) {
            _filter = v;
            _apply();
          },
        ),
      );

  Widget _statusBadge(String s) {
    final color = s == 'Nouvo'
        ? Colors.cyan
        : s == 'Chal'
            ? Colors.orange
            : Colors.green;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(
          color: color.withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(6)),
      child: Text(s,
          style: TextStyle(
              fontSize: 10, color: color, fontWeight: FontWeight.bold)),
    );
  }
}
