import 'package:flutter/material.dart';
import '../models/prospect.dart';
import '../services/apify_service.dart';
import '../services/firecrawl_service.dart';
import '../services/settings_service.dart';
import '../services/storage.dart';

class ScrapeScreen extends StatefulWidget {
  const ScrapeScreen({super.key});
  @override
  State<ScrapeScreen> createState() => _ScrapeScreenState();
}

class _ScrapeScreenState extends State<ScrapeScreen> {
  String _method = 'apify';
  String _category = 'Otèl';
  String _city = 'Cap-Haïtien';
  int _max = 30;
  bool _running = false;
  String _log = '';
  List<Prospect> _results = [];

  static const _cities = [
    'Cap-Haïtien', 'Port-au-Prince', 'Gonaïves', 'Les Cayes', 'Jacmel', 'Pétion-Ville'
  ];
  static const _cats = ['Otèl', 'Restoran', 'Lekòl', 'Klinik', 'Boutik', 'Lòt'];

  void _addLog(String m) {
    if (mounted) setState(() => _log += '$m\n');
  }

  Future<void> _start() async {
    final s = await SettingsService.load();
    final token = (_method == 'apify' ? s['apify'] : s['firecrawl']) ?? '';
    if (token.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
                'Mete ${_method == 'apify' ? 'Apify token' : 'Firecrawl key'} nan Paramèt')));
      }
      return;
    }
    setState(() {
      _running = true;
      _log = '';
      _results = [];
    });

    try {
      final term = '$_category $_city Haiti';
      final List<Prospect> result;
      if (_method == 'apify') {
        result = await ApifyService(token).scrape(
            searchTerm: term,
            category: _category,
            maxResults: _max,
            onProgress: _addLog);
      } else {
        result = await FirecrawlService(token).scrape(
            query: term,
            category: _category,
            city: _city,
            limit: _max,
            onProgress: _addLog);
      }
      if (mounted) {
        setState(() {
          _results = result;
          _log += '\n✓ ${result.length} biznis!';
        });
      }
    } catch (e) {
      _addLog('\n✗ Erè: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  Future<void> _save() async {
    if (_results.isEmpty) return;
    final added = await Storage.addMany(_results);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('✓ $added nouvo anrejistre (${_results.length - added} doublon sote)'),
        backgroundColor: Colors.green));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('🔍 Scraping')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(
                  value: 'apify', label: Text('Apify'), icon: Icon(Icons.cloud)),
              ButtonSegment(
                  value: 'firecrawl',
                  label: Text('Firecrawl'),
                  icon: Icon(Icons.local_fire_department)),
            ],
            selected: {_method},
            onSelectionChanged: (v) => setState(() => _method = v.first),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _category,
            decoration: const InputDecoration(
                labelText: 'Kategori', border: OutlineInputBorder()),
            items: _cats
                .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                .toList(),
            onChanged: (v) => setState(() => _category = v!),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _city,
            decoration: const InputDecoration(
                labelText: 'Vil', border: OutlineInputBorder()),
            items: _cities
                .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                .toList(),
            onChanged: (v) => setState(() => _city = v!),
          ),
          const SizedBox(height: 12),
          TextFormField(
            initialValue: '$_max',
            decoration: const InputDecoration(
                labelText: 'Kantite max', border: OutlineInputBorder()),
            keyboardType: TextInputType.number,
            onChanged: (v) => _max = (int.tryParse(v) ?? 30).clamp(1, 100),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _running ? null : _start,
            icon: _running
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.play_arrow),
            label: Text(_running ? 'Ap travay...' : 'Kòmanse'),
          ),
          if (_log.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  color: Colors.black87, borderRadius: BorderRadius.circular(8)),
              child: Text(_log,
                  style: const TextStyle(
                      color: Colors.greenAccent,
                      fontFamily: 'monospace',
                      fontSize: 11)),
            ),
          ],
          if (_results.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text('${_results.length} rezilta:',
                style: Theme.of(c).textTheme.titleMedium),
            ..._results.take(8).map((p) => ListTile(
                  dense: true,
                  leading: const Icon(Icons.store, size: 18),
                  title:
                      Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(p.phone.isEmpty ? 'Pa gen nimewo' : p.phone),
                )),
            const SizedBox(height: 12),
            FilledButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.save),
                label: Text('Anrejistre ${_results.length} pwospek')),
          ],
        ]),
      );
}
