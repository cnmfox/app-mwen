import 'package:flutter/material.dart';
import '../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _apifyCtrl = TextEditingController();
  final _fcCtrl = TextEditingController();
  bool _hide = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await SettingsService.load();
    _apifyCtrl.text = s['apify'] ?? '';
    _fcCtrl.text = s['firecrawl'] ?? '';
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    await SettingsService.save(
        apify: _apifyCtrl.text.trim(), firecrawl: _fcCtrl.text.trim());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('✓ Kle anrejistre'), backgroundColor: Colors.green));
    }
  }

  Widget _keyField(TextEditingController c, String label, String hint, String help) =>
      TextField(
        controller: c,
        obscureText: _hide,
        decoration: InputDecoration(
            labelText: label,
            border: const OutlineInputBorder(),
            hintText: hint,
            helperText: help),
      );

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('⚙️ Paramèt')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            const Expanded(
                child: Text('API Keys',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
            IconButton(
                icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => _hide = !_hide)),
          ]),
          const Text('Kle yo rete sèlman sou telefòn ou. Pa pataje APK la.',
              style: TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 16),
          _keyField(_apifyCtrl, 'Apify Token', 'apify_api_xxxxx',
              'apify.com → Settings → Integrations'),
          const SizedBox(height: 16),
          _keyField(_fcCtrl, 'Firecrawl Key', 'fc-xxxxx',
              'firecrawl.dev → Dashboard'),
          const SizedBox(height: 20),
          FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: const Text('Anrejistre'),
              style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(48))),
          const Divider(height: 40),
          const Text('Sou app la',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('cnmfox Mobile v1.2 — Pèsonèl\n'
              'Done yo rete sou telefòn ou. Fè backup ak Ekspòte CSV.'),
        ]),
      );
}
