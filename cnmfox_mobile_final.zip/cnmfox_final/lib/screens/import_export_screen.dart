import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../services/csv_service.dart';
import '../services/report_service.dart';
import '../services/storage.dart';

class ImportExportScreen extends StatefulWidget {
  const ImportExportScreen({super.key});
  @override
  State<ImportExportScreen> createState() => _ImportExportScreenState();
}

class _ImportExportScreenState extends State<ImportExportScreen> {
  bool _busy = false;

  void _snack(String m) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    }
  }

  Future<void> _run(Future<void> Function() job) async {
    setState(() => _busy = true);
    try {
      await job();
    } catch (e) {
      _snack('✗ ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _export() => _run(() async {
        final list = await Storage.loadAll();
        if (list.isEmpty) throw Exception('Pa gen done pou ekspòte');
        final path = await CsvService.exportCsv(list);
        await Share.shareXFiles([XFile(path)], subject: 'cnmfox pwospek');
      });

  Future<void> _import() => _run(() async {
        final n = await CsvService.importCsv();
        _snack(n > 0 ? '✓ $n pwospek enpòte' : 'Anyen nouvo pou enpòte');
      });

  Future<void> _report() => _run(() async {
        final list = await Storage.loadAll();
        if (list.isEmpty) throw Exception('Pa gen done');
        final path = await ReportService.generate(list);
        await Share.shareXFiles([XFile(path)], subject: 'cnmfox rapò');
      });

  Widget _tile(IconData i, Color c, String t, String s, VoidCallback f) => Card(
        child: ListTile(
          leading: Icon(i, color: c),
          title: Text(t),
          subtitle: Text(s),
          trailing: _busy
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.chevron_right),
          onTap: _busy ? null : f,
        ),
      );

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('📤 Enpòte / Ekspòte')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          _tile(Icons.upload_file, Colors.blue, 'Ekspòte CSV (backup)',
              'Pataje tout pwospek ou (WhatsApp, Drive, elatriye)', _export),
          _tile(Icons.download, Colors.green, 'Enpòte CSV',
              'Chwazi yon fichye CSV (doublon yo sote)', _import),
          _tile(Icons.description, Colors.orange, 'Jenere rapò (txt)',
              'Kreye yon rapò epi pataje l', _report),
        ]),
      );
}
