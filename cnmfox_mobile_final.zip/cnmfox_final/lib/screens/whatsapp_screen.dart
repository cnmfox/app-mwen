import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/prospect.dart';
import '../services/storage.dart';
import '../services/whatsapp_templates.dart';

class WhatsAppScreen extends StatefulWidget {
  const WhatsAppScreen({super.key});
  @override
  State<WhatsAppScreen> createState() => _WhatsAppScreenState();
}

class _WhatsAppScreenState extends State<WhatsAppScreen> {
  List<Prospect> _prospects = [];
  Prospect? _selected;
  int _tmplIndex = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _prospects = (await Storage.loadAll())
      ..sort((a, b) => a.name.compareTo(b.name));
    if (mounted) setState(() {});
  }

  Future<void> _launch(Prospect p, String msg) async {
    final digits = p.waNumber;
    final url =
        Uri.parse('https://wa.me/$digits?text=${Uri.encodeComponent(msg)}');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Pa ka louvri WhatsApp')));
    }
  }

  @override
  Widget build(BuildContext c) {
    final tmpls = _selected == null
        ? <({String label, String body})>[]
        : WhatsAppTemplates.forProspect(
            name: _selected!.name, hasWebsite: _selected!.hasWebsite);
    return Scaffold(
      appBar: AppBar(title: const Text('💬 WhatsApp')),
      body: _prospects.isEmpty
          ? const Center(child: Text('Pa gen pwospek. Ajoute youn dabò.'))
          : ListView(padding: const EdgeInsets.all(12), children: [
              DropdownButtonFormField<int>(
                decoration: const InputDecoration(
                    labelText: 'Chwazi pwospek', border: OutlineInputBorder()),
                isExpanded: true,
                value: _selected?.id,
                items: _prospects
                    .map((p) => DropdownMenuItem(
                          value: p.id,
                          child: Text('${p.name} (${p.category})',
                              overflow: TextOverflow.ellipsis),
                        ))
                    .toList(),
                onChanged: (id) => setState(() {
                  _selected = _prospects.firstWhere((p) => p.id == id);
                  _tmplIndex = 0;
                }),
              ),
              const SizedBox(height: 16),
              if (_selected != null) ...[
                Row(children: [
                  Icon(
                      _selected!.hasWhatsApp
                          ? Icons.phone
                          : Icons.phone_disabled,
                      color: _selected!.hasWhatsApp ? Colors.green : Colors.red),
                  const SizedBox(width: 6),
                  Text(_selected!.hasWhatsApp
                      ? _selected!.phone
                      : 'Pa gen nimewo'),
                  const SizedBox(width: 12),
                  Icon(
                      _selected!.hasWebsite
                          ? Icons.language
                          : Icons.language_outlined,
                      color: _selected!.hasWebsite ? Colors.blue : Colors.grey),
                  const SizedBox(width: 4),
                  Text(_selected!.hasWebsite ? 'Gen sit' : 'San sit'),
                ]),
                const SizedBox(height: 16),
                Text('Modèl mesaj:', style: Theme.of(c).textTheme.titleMedium),
                const SizedBox(height: 8),
                ...tmpls.asMap().entries.map((e) => Card(
                      color: _tmplIndex == e.key
                          ? Colors.green.withValues(alpha: 0.1)
                          : null,
                      child: ListTile(
                        leading: Icon(_tmplIndex == e.key
                            ? Icons.radio_button_checked
                            : Icons.radio_button_off),
                        title: Text(e.value.label),
                        onTap: () => setState(() => _tmplIndex = e.key),
                      ),
                    )),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(8),
                    border:
                        Border.all(color: Colors.green.withValues(alpha: 0.4)),
                  ),
                  child: SelectableText(tmpls[_tmplIndex].body),
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  icon: const Icon(Icons.chat),
                  label: const Text('Louvri nan WhatsApp'),
                  onPressed: _selected!.hasWhatsApp
                      ? () => _launch(_selected!, tmpls[_tmplIndex].body)
                      : null,
                ),
              ],
            ]),
    );
  }
}
