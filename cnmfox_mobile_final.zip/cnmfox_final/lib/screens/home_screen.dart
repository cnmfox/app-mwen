import 'package:flutter/material.dart';
import '../models/prospect.dart';
import '../services/storage.dart';
import 'whatsapp_screen.dart';
import 'scrape_screen.dart';
import 'import_export_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Prospect> _all = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _all = await Storage.loadAll();
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext c) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final t = _all.length;
    final n = _all.where((p) => p.status == 'Nouvo').length;
    final ch = _all.where((p) => p.status == 'Chal').length;
    final k = _all.where((p) => p.status == 'Kliyan').length;
    final wa = _all.where((p) => p.hasWhatsApp).length;
    final web = _all.where((p) => p.hasWebsite).length;
    final noWeb = t - web;
    final revenue = _all.fold<double>(0, (a, p) => a + p.dealValue);

    return Scaffold(
      appBar: AppBar(
        title: const Text('cnmfox 🦊'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load)],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          _bigStat('Total pwospek', '$t', Icons.people, Colors.blue),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: _smallStat('Nouvo', '$n', Colors.cyan)),
            const SizedBox(width: 8),
            Expanded(child: _smallStat('Chal', '$ch', Colors.orange)),
            const SizedBox(width: 8),
            Expanded(child: _smallStat('Kliyan', '$k', Colors.green)),
          ]),
          const SizedBox(height: 16),
          Card(
              child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('📊 Estatistik',
                          style: Theme.of(c).textTheme.titleMedium),
                      const Divider(),
                      _kv('📱 Ak WhatsApp', '$wa'),
                      _kv('🌐 Ak sit wèb', '$web'),
                      _kv('❌ San sit wèb', '$noWeb', highlight: true),
                      _kv('💰 Revni total', '\$${revenue.toStringAsFixed(2)}'),
                    ],
                  ))),
          const SizedBox(height: 16),
          Text('⚡ Aksyon rapid', style: Theme.of(c).textTheme.titleMedium),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            ActionChip(
              avatar: const Icon(Icons.calendar_today, size: 16),
              label: Text('Kontakte jodi a ($n)'),
              onPressed: () => _showFollowup(c),
            ),
            ActionChip(
              avatar: const Icon(Icons.chat, size: 16, color: Colors.green),
              label: const Text('WhatsApp'),
              onPressed: () => Navigator.push(c,
                  MaterialPageRoute(builder: (_) => const WhatsAppScreen())),
            ),
            ActionChip(
              avatar: const Icon(Icons.travel_explore,
                  size: 16, color: Colors.deepPurple),
              label: const Text('Scraping'),
              onPressed: () => Navigator.push(c,
                      MaterialPageRoute(builder: (_) => const ScrapeScreen()))
                  .then((_) => _load()),
            ),
            ActionChip(
              avatar: const Icon(Icons.import_export,
                  size: 16, color: Colors.indigo),
              label: const Text('Enpòte / Ekspòte'),
              onPressed: () => Navigator.push(
                      c,
                      MaterialPageRoute(
                          builder: (_) => const ImportExportScreen()))
                  .then((_) => _load()),
            ),
          ]),
        ]),
      ),
    );
  }

  Widget _bigStat(String l, String v, IconData i, Color c) => Card(
        color: c.withValues(alpha: 0.1),
        child: ListTile(
          leading: Icon(i, size: 36, color: c),
          title: Text(l),
          trailing: Text(v,
              style: TextStyle(
                  fontSize: 32, fontWeight: FontWeight.bold, color: c)),
        ),
      );

  Widget _smallStat(String l, String v, Color c) => Card(
        color: c.withValues(alpha: 0.1),
        child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(children: [
              Text(v,
                  style: TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold, color: c)),
              Text(l, style: const TextStyle(fontSize: 12)),
            ])),
      );

  Widget _kv(String k, String v, {bool highlight = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k),
          Text(v,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: highlight ? Colors.deepOrange : null)),
        ]),
      );

  void _showFollowup(BuildContext ctx) async {
    final list = await Storage.loadAll();
    final items = list.where((p) => p.status == 'Nouvo').toList()
      ..sort((a, b) => (b.hasWhatsApp ? 1 : 0).compareTo(a.hasWhatsApp ? 1 : 0));
    if (!ctx.mounted) return;
    showModalBottomSheet(
        context: ctx,
        isScrollControlled: true,
        builder: (_) => DraggableScrollableSheet(
            expand: false,
            initialChildSize: 0.8,
            builder: (_, sc) => ListView(
                    controller: sc,
                    padding: const EdgeInsets.all(16),
                    children: [
                      Text('📅 ${items.length} moun pou kontakte',
                          style: Theme.of(ctx).textTheme.titleLarge),
                      const SizedBox(height: 8),
                      ...items.map((p) => ListTile(
                            leading: CircleAvatar(
                                backgroundColor:
                                    p.hasWhatsApp ? Colors.green : Colors.grey,
                                child: Icon(
                                    p.hasWhatsApp
                                        ? Icons.phone
                                        : Icons.phone_disabled,
                                    color: Colors.white,
                                    size: 18)),
                            title: Text(p.name),
                            subtitle: Text(
                                '${p.category} • ${p.hasWhatsApp ? "WhatsApp ✓" : "Pa gen WA"} • ${p.hasWebsite ? "Sit ✓" : "San sit"}'),
                          )),
                    ])));
  }
}
