import 'package:flutter/material.dart';
import '../models/prospect.dart';
import '../services/storage.dart';

class ProspectEditScreen extends StatefulWidget {
  final Prospect? prospect;
  const ProspectEditScreen({super.key, this.prospect});
  @override
  State<ProspectEditScreen> createState() => _ProspectEditScreenState();
}

class _ProspectEditScreenState extends State<ProspectEditScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name,
      _cat,
      _addr,
      _phone,
      _web,
      _maps,
      _rating,
      _notes,
      _pkg;
  late String _status;
  late double _deal;

  @override
  void initState() {
    super.initState();
    final p = widget.prospect;
    _name = TextEditingController(text: p?.name ?? '');
    _cat = TextEditingController(text: p?.category ?? 'Lòt');
    _addr = TextEditingController(text: p?.address ?? '');
    _phone = TextEditingController(text: p?.phone ?? '');
    _web = TextEditingController(text: p?.website ?? '');
    _maps = TextEditingController(text: p?.mapsUrl ?? '');
    _rating = TextEditingController(text: p?.rating ?? '');
    _notes = TextEditingController(text: p?.notes ?? '');
    _pkg = TextEditingController(text: p?.packageOffered ?? '');
    _status = p?.status ?? 'Nouvo';
    _deal = p?.dealValue ?? 0;
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final all = await Storage.loadAll();
    final existing = widget.prospect;
    final isNew = existing == null;
    final p = isNew
        ? Prospect(id: await Storage.nextId(), name: '')
        : all.firstWhere((x) => x.id == existing.id, orElse: () => existing);
    p.name = _name.text.trim();
    p.category = _cat.text.trim();
    p.address = _addr.text.trim();
    p.phone = _phone.text.trim();
    p.website = _web.text.trim();
    p.mapsUrl = _maps.text.trim();
    p.rating = _rating.text.trim();
    p.notes = _notes.text.trim();
    p.packageOffered = _pkg.text.trim();
    p.status = _status;
    p.dealValue = _deal;
    if (isNew) {
      p.date = DateTime.now().toIso8601String().substring(0, 10);
      p.source = 'Manyèl';
      all.add(p);
    } else if (!all.any((x) => x.id == p.id)) {
      all.add(p);
    }
    await Storage.saveAll(all);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(
            title: Text(widget.prospect == null ? 'Nouvo pwospek' : 'Modifye')),
        body: Form(
            key: _form,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              _field(_name, 'Non *', required: true),
              _field(_cat, 'Kategori'),
              _field(_addr, 'Adrès'),
              _field(_phone, 'Telefòn / WhatsApp',
                  keyboard: TextInputType.phone),
              _field(_web, 'Sit wèb'),
              _field(_maps, 'Lyen Google Maps'),
              _field(_rating, 'Rating'),
              _field(_notes, 'Nòt', maxLines: 3),
              _field(_pkg, 'Pake ofri (Basic/Pro/Premium)'),
              DropdownButtonFormField<String>(
                value: _status,
                decoration: const InputDecoration(
                    labelText: 'Estat', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'Nouvo', child: Text('Nouvo')),
                  DropdownMenuItem(value: 'Chal', child: Text('Chal')),
                  DropdownMenuItem(value: 'Kliyan', child: Text('Kliyan')),
                ],
                onChanged: (v) => setState(() => _status = v!),
              ),
              const SizedBox(height: 12),
              TextFormField(
                initialValue: _deal.toString(),
                decoration: const InputDecoration(
                    labelText: 'Valè deal (\$)', border: OutlineInputBorder()),
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                onChanged: (v) => _deal = double.tryParse(v) ?? 0,
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.save),
                  label: const Text('Anrejistre')),
            ])),
      );

  Widget _field(TextEditingController ctrl, String label,
          {bool required = false,
          TextInputType? keyboard,
          int maxLines = 1}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: ctrl,
          maxLines: maxLines,
          keyboardType: keyboard,
          validator: required
              ? (v) => (v == null || v.trim().isEmpty) ? 'Obligatwa' : null
              : null,
          decoration: InputDecoration(
              labelText: label, border: const OutlineInputBorder()),
        ),
      );
}
