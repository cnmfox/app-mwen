import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/prospect_list_screen.dart';
import 'screens/settings_screen.dart';

void main() => runApp(const CnmfoxApp());

class CnmfoxApp extends StatelessWidget {
  const CnmfoxApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        title: 'cnmfox',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0066CC)),
          useMaterial3: true,
        ),
        home: const RootScreen(),
      );
}

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});
  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int _index = 0;
  Key _homeKey = UniqueKey();
  Key _listKey = UniqueKey();

  @override
  Widget build(BuildContext c) => Scaffold(
        body: IndexedStack(index: _index, children: [
          HomeScreen(key: _homeKey),
          ProspectListScreen(key: _listKey),
          const SettingsScreen(),
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() {
            _index = i;
            // rechaje done yo chak fwa w chanje tab
            if (i == 0) _homeKey = UniqueKey();
            if (i == 1) _listKey = UniqueKey();
          }),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard), label: 'Akèy'),
            NavigationDestination(icon: Icon(Icons.people), label: 'Pwospek'),
            NavigationDestination(icon: Icon(Icons.settings), label: 'Paramèt'),
          ],
        ),
      );
}
