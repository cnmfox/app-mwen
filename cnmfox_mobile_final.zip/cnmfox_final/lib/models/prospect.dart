class Prospect {
  int id;
  String name, category, address, phone, website, mapsUrl, rating;
  String status; // Nouvo | Chal | Kliyan
  String date, lastFollowup, notes, source;
  String packageOffered; // Basic | Pro | Premium
  double dealValue;

  Prospect({
    required this.id, required this.name,
    this.category = 'Lòt', this.address = '', this.phone = '',
    this.website = '', this.mapsUrl = '', this.rating = '',
    this.status = 'Nouvo', this.date = '', this.lastFollowup = '',
    this.notes = '', this.source = 'Manyèl',
    this.packageOffered = '', this.dealValue = 0,
  });

  bool get hasWhatsApp => phone.trim().isNotEmpty;
  bool get hasWebsite => website.trim().isNotEmpty;

  /// Nimewo pou wa.me (chif sèlman). 8 chif lokal => ajoute 509 (Ayiti).
  String get waNumber {
    var d = phone.replaceAll(RegExp(r'[^\d]'), '');
    if (d.startsWith('00')) d = d.substring(2);
    if (d.length == 8) d = '509$d';
    return d;
  }

  factory Prospect.fromJson(Map<String, dynamic> j) => Prospect(
        id: j['id'] ?? 0,
        name: j['name'] ?? '',
        category: j['category'] ?? 'Lòt',
        address: j['address'] ?? '',
        phone: j['phone'] ?? '',
        website: j['website'] ?? '',
        mapsUrl: j['maps_url'] ?? '',
        rating: (j['rating'] ?? '').toString(),
        status: j['status'] ?? 'Nouvo',
        date: j['date'] ?? '',
        lastFollowup: j['last_followup'] ?? '',
        notes: j['notes'] ?? '',
        source: j['source'] ?? '',
        packageOffered: j['package_offered'] ?? '',
        dealValue: (j['deal_value'] ?? 0).toDouble(),
      );

  Map<String, dynamic> toJson() => {
        'id': id, 'name': name, 'category': category,
        'address': address, 'phone': phone, 'website': website,
        'maps_url': mapsUrl, 'rating': rating, 'status': status,
        'date': date, 'last_followup': lastFollowup, 'notes': notes,
        'source': source, 'package_offered': packageOffered,
        'deal_value': dealValue,
      };
}
