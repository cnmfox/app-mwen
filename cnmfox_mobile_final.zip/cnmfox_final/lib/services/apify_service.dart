import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/prospect.dart';
import 'utils.dart';

class ApifyService {
  final String token;
  ApifyService(this.token);
  static const _actorId = 'compass~crawler-google-places';

  Future<List<Prospect>> scrape({
    required String searchTerm,
    required String category,
    int maxResults = 50,
    void Function(String)? onProgress,
  }) async {
    onProgress?.call('🚀 Kòmanse Apify...');

    final runResp = await http
        .post(
          Uri.parse('https://api.apify.com/v2/acts/$_actorId/runs?token=$token'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'searchStringsArray': [searchTerm],
            'language': 'fr',
            'maxCrawledPlacesPerSearch': maxResults,
            'maxCrawledPlaces': maxResults,
            'maxImages': 0,
            'maxReviews': 0,
          }),
        )
        .timeout(const Duration(seconds: 30));

    if (runResp.statusCode >= 400) {
      throw Exception('Apify HTTP ${runResp.statusCode}: ${cut(runResp.body, 150)}');
    }

    final runId = (jsonDecode(runResp.body)['data']?['id']) as String?;
    if (runId == null) throw Exception('Pa gen run ID');
    onProgress?.call('✓ Run kreye\n⏳ Ap tann Apify (30-120s)...');

    for (int i = 0; i < 60; i++) {
      await Future.delayed(const Duration(seconds: 5));
      http.Response sResp;
      try {
        sResp = await http
            .get(Uri.parse('https://api.apify.com/v2/actor-runs/$runId?token=$token'))
            .timeout(const Duration(seconds: 20));
      } catch (_) {
        continue;
      }
      if (sResp.statusCode >= 400) continue;

      final data = jsonDecode(sResp.body)['data'] as Map<String, dynamic>? ?? {};
      final status = data['status'] as String? ?? 'UNKNOWN';
      onProgress?.call('⏳ (${i + 1}/60) — $status');

      if (status == 'SUCCEEDED') {
        final datasetId = data['defaultDatasetId'] as String?;
        if (datasetId == null) throw Exception('Pa gen dataset');
        final itemsResp = await http
            .get(Uri.parse(
                'https://api.apify.com/v2/datasets/$datasetId/items?token=$token&clean=true&format=json'))
            .timeout(const Duration(seconds: 60));
        if (itemsResp.statusCode >= 400) {
          throw Exception('Erè done: ${itemsResp.statusCode}');
        }
        final items = jsonDecode(itemsResp.body) as List;
        return items
            .map((r) => _toProspect(r as Map<String, dynamic>, category))
            .where((p) => p.name.isNotEmpty)
            .toList();
      } else if (['FAILED', 'TIMED-OUT', 'ABORTED'].contains(status)) {
        throw Exception('Run echwe: $status');
      }
    }
    throw Exception('Tan limite depase');
  }

  Prospect _toProspect(Map<String, dynamic> i, String cat) => Prospect(
        id: 0,
        name: (i['title'] ?? '').toString(),
        category: cat,
        address: (i['address'] ?? '').toString(),
        phone: (i['phone'] ?? i['phoneUnformatted'] ?? '').toString(),
        website: (i['website'] ?? '').toString(),
        mapsUrl: (i['url'] ?? '').toString(),
        rating: (i['totalScore'] ?? '').toString(),
        status: 'Nouvo',
        date: DateTime.now().toIso8601String().substring(0, 10),
        notes: 'Revi: ${i['reviewsCount'] ?? ''}',
        source: 'Apify',
      );
}
