String cut(String s, int n) => s.length <= n ? s : s.substring(0, n);
