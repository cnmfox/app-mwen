import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/prospect.dart';

class Storage {
  static const _file = 'cnmfox_prospects.json';

  static Future<File> _getFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_file');
  }

  static Future<List<Prospect>> loadAll() async {
    final f = await _getFile();
    if (!await f.exists()) return [];
    final raw = await f.readAsString();
    if (raw.trim().isEmpty) return [];
    return (jsonDecode(raw) as List).map((e) => Prospect.fromJson(e)).toList();
  }

  static Future<void> saveAll(List<Prospect> list) async {
    final f = await _getFile();
    await f.writeAsString(jsonEncode(list.map((p) => p.toJson()).toList()));
  }

  static Future<int> nextId() async {
    final list = await loadAll();
    if (list.isEmpty) return 1;
    return list.map((p) => p.id).reduce((a, b) => a > b ? a : b) + 1;
  }

  static String _key(Prospect p) =>
      '${p.name.toLowerCase().trim()}|${p.phone.replaceAll(RegExp(r'[^\d]'), '')}';

  /// Ajoute plizyè pwospek, sote doublon (menm non + telefòn). Retounen konbyen ajoute.
  static Future<int> addMany(List<Prospect> items) async {
    final all = await loadAll();
    final keys = all.map(_key).toSet();
    var next = all.isEmpty ? 1 : all.map((p) => p.id).reduce((a, b) => a > b ? a : b) + 1;
    var added = 0;
    for (final p in items) {
      if (p.name.trim().isEmpty) continue;
      final k = _key(p);
      if (keys.contains(k)) continue;
      keys.add(k);
      p.id = next++;
      all.add(p);
      added++;
    }
    await saveAll(all);
    return added;
  }
}
