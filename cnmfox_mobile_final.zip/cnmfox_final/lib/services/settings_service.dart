import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class SettingsService {
  static Future<File> _cfg() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/cnmfox_keys.json');
  }

  static Future<Map<String, String>> load() async {
    try {
      final f = await _cfg();
      if (!await f.exists()) return {};
      final raw = await f.readAsString();
      if (raw.trim().isEmpty) return {};
      final m = jsonDecode(raw) as Map<String, dynamic>;
      return {
        'apify': (m['apify'] ?? '').toString(),
        'firecrawl': (m['firecrawl'] ?? '').toString(),
      };
    } catch (_) {
      return {};
    }
  }

  static Future<void> save({String? apify, String? firecrawl}) async {
    final cur = await load();
    final f = await _cfg();
    await f.writeAsString(jsonEncode({
      'apify': apify ?? cur['apify'] ?? '',
      'firecrawl': firecrawl ?? cur['firecrawl'] ?? '',
    }));
  }
}
