class WhatsAppTemplates {
  static const sender = 'Norgaisse Charles Michel';

  static List<({String label, String body})> forProspect({
    required String name,
    required bool hasWebsite,
  }) {
    if (hasWebsite) {
      return [
        (
          label: '1. Premye kontak (gen sit)',
          body: 'Bonjou, mwen se $sender, devlopè web nan cnmfox.\n\n'
              'Mwen remake $name gen yon sit wèb deja. Mwen ta renmen ede w '
              'AMELYORE l pou atiran plis kliyan.\n\nEske ou gen yon ti tan pou nou pale?',
        ),
        (
          label: '2. Ofri amelyorasyon',
          body: 'Bonjou, mwen remake sit wèb $name. Mwen gen eksperyans pou '
              'AMELYORE vitès, dizèn, ak ranje sou Google.\n\n'
              'Mwen ta renmen fè yon ANALIZ GRATIS. Ou enterese?',
        ),
        (
          label: '3. Follow-up',
          body: 'Bonjou, mwen te kontakte w sou sit wèb $name. Ou enterese '
              'pou nou amelyore l? Mwen gen ofri espesyal pou biznis Ayisyen.',
        ),
        (
          label: '4. Dènye apwòch',
          body: 'Bonjou, dènye fwa mwen kontakte w sou sit $name.\n\n'
              'Si pa enterese, reponn *PA ENTERESE*. Si wi, reponn *WI*.',
        ),
      ];
    }
    return [
      (
        label: '1. Premye kontak (san sit)',
        body: 'Bonjou, mwen se $sender, devlopè web nan cnmfox.\n\n'
            'Mwen remake $name pa gen yon sit ofisyèl. Mwen ta renmen '
            'ede w kreye yon bèl sit pou atiran plis kliyan.\n\n'
            'Eske ou gen yon ti tan?',
      ),
      (
        label: '2. Ofri kreye sit',
        body: 'Bonjou, mwen vle ede $name gen yon pwofesyonèl sit wèb!\n\n'
            'Avek yon sit, kliyan ka jwenn ou sou Google, wè foto, epi '
            'kontakte w fasil.\n\nPrix kòmanse nan \$100 USD. Ou enterese?',
      ),
      (
        label: '3. Follow-up + 30%',
        body: 'Bonjou, ofri espesyal pou $name!\n\n'
            'Jodi a sèlman: 30% RABA. Kòmanse ak \$70 USD olye de \$100.\n\n'
            'Valab jiska vandredi. Ou enterese?',
      ),
      (
        label: '4. Gid gratis',
        body: 'Bonjou, mwen gen yon GID GRATIS pou $name: '
            '*"5 Rezon poukisa yon biznis Ayisyen bezwen yon sit wèb"*.\n\n'
            'Reponn *GUIDE* pou mwen voye l.',
      ),
      (
        label: '5. Dènye apwòch',
        body: 'Bonjou, dènye fwa mwen kontakte w pou $name.\n\n'
            'Si pa enterese, reponn *PA ENTERESE*. Si wi, reponn *WI*.',
      ),
    ];
  }
}
