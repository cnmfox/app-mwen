import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/prospect.dart';
import 'utils.dart';

class FirecrawlService {
  final String apiKey;
  FirecrawlService(this.apiKey);
  static const _base = 'https://api.firecrawl.dev/v1';

  Map<String, String> get _headers =>
      {'Authorization': 'Bearer $apiKey', 'Content-Type': 'application/json'};

  Future<List<Prospect>> scrape({
    required String query,
    required String category,
    required String city,
    int limit = 20,
    void Function(String)? onProgress,
  }) async {
    onProgress?.call('🔥 Chèche: "$query"');

    final searchResp = await http
        .post(
          Uri.parse('$_base/search'),
          headers: _headers,
          body: jsonEncode({
            'query': query,
            'limit': (limit * 3).clamp(1, 100),
            'lang': 'fr',
            'country': 'ht',
          }),
        )
        .timeout(const Duration(seconds: 60));

    if (searchResp.statusCode >= 400) {
      throw Exception('HTTP ${searchResp.statusCode}: ${cut(searchResp.body, 150)}');
    }

    final searchData = jsonDecode(searchResp.body) as Map<String, dynamic>;
    if (searchData['success'] != true) {
      throw Exception('Search echwe: ${searchData['message'] ?? ''}');
    }

    final all = (searchData['data'] as List? ?? []).cast<Map<String, dynamic>>();
    final places =
        all.where((r) => (r['url'] ?? '').toString().contains('/place/')).toList();
    onProgress?.call('✓ ${places.length} paj biznis (${all.length - places.length} lòt)');
    if (places.isEmpty) {
      onProgress?.call('⚠ Pa gen paj Google Maps. Eseye Apify, li pi serye.');
    }

    final results = <Prospect>[];
    for (int i = 0; i < places.length && results.length < limit; i++) {
      final item = places[i];
      onProgress?.call(
          '📄 [${i + 1}/${places.length}] ${cut((item['title'] ?? '???').toString(), 30)}');
      final scraped = await _scrapeUrl(item['url'] as String);
      final p = _toProspect(item, scraped, category, city);
      if (p != null) results.add(p);
      await Future.delayed(const Duration(seconds: 1));
    }
    return results;
  }

  Future<Map<String, dynamic>?> _scrapeUrl(String url) async {
    try {
      final resp = await http
          .post(Uri.parse('$_base/scrape'),
              headers: _headers,
              body: jsonEncode({'url': url, 'formats': ['markdown']}))
          .timeout(const Duration(seconds: 45));
      if (resp.statusCode >= 400) return null;
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      if (data['success'] != true) return null;
      return data['data'] as Map<String, dynamic>?;
    } catch (_) {
      return null;
    }
  }

  Prospect? _toProspect(
      Map<String, dynamic> item, Map<String, dynamic>? s, String cat, String city) {
    final title = (item['title'] ?? '').toString();
    final url = (item['url'] ?? '').toString();
    if (title.length < 2) return null;
    final md = (s?['markdown'] ?? '').toString();
    final desc = (item['description'] ?? '').toString();
    final addr = _addr(md);
    final ph = _phone(md);
    final web = _web(md);
    return Prospect(
      id: 0,
      name: title,
      category: cat,
      address: addr.isNotEmpty ? addr : '',
      phone: ph.isNotEmpty ? ph : _phone(desc),
      website: web,
      mapsUrl: url,
      status: 'Nouvo',
      date: DateTime.now().toIso8601String().substring(0, 10),
      notes: 'Vil: $city',
      source: 'Firecrawl',
    );
  }

  String _phone(String t) {
    if (t.isEmpty) return '';
    for (final pat in [
      RegExp(r'\+509[\s\-]?\d{2}[\s\-]?\d{2}[\s\-]?\d{2}[\s\-]?\d{2}'),
      RegExp(r'\+509[\s\-]?\d{4}[\s\-]?\d{4}'),
      RegExp(r'\+509[\s\-]?\d{8}'),
    ]) {
      final m = pat.firstMatch(t);
      if (m != null) return m.group(0)!.replaceAll(RegExp(r'[\s\-]'), '');
    }
    return '';
  }

  String _addr(String t) {
    if (t.isEmpty) return '';
    const kws = [
      'haiti', 'haïti', 'rue', 'route', 'avenue', 'boulevard',
      'cap-haitien', 'port-au-prince', 'jacmel', 'les cayes', 'gonaives'
    ];
    for (final line in t.split('\n')) {
      final l = line.toLowerCase();
      if (kws.any((k) => l.contains(k))) {
        final x = line.trim();
        if (x.length > 10 && x.length < 200) return x;
      }
    }
    return '';
  }

  String _web(String t) {
    if (t.isEmpty) return '';
    const skip = ['google', 'gstatic', 'goo.gl', 'googleusercontent', 'ggpht'];
    final re = RegExp(r'https?://(?:www\.)?([^\s/)\]]+\.(?:com|ht|net|org))',
        caseSensitive: false);
    for (final m in re.allMatches(t)) {
      final d = m.group(1)!;
      if (!skip.any((s) => d.toLowerCase().contains(s))) return d;
    }
    return '';
  }
}
