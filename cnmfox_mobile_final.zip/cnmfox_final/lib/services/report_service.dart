import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/prospect.dart';

class ReportService {
  static String _two(int n) => n.toString().padLeft(2, '0');

  static Future<String> generate(List<Prospect> list) async {
    final b = StringBuffer();
    final now = DateTime.now();
    final ds = '${now.year}-${_two(now.month)}-${_two(now.day)} '
        '${_two(now.hour)}:${_two(now.minute)}';

    b.writeln('=' * 50);
    b.writeln('  cnmfox - RAPÒ PWOSPEKTE');
    b.writeln('  Jenere: $ds');
    b.writeln('=' * 50);
    b.writeln();

    final n = list.where((p) => p.status == 'Nouvo').length;
    final ch = list.where((p) => p.status == 'Chal').length;
    final k = list.where((p) => p.status == 'Kliyan').length;
    final wa = list.where((p) => p.hasWhatsApp).length;
    final web = list.where((p) => p.hasWebsite).length;
    final revenue = list.fold<double>(0, (a, p) => a + p.dealValue);

    b.writeln('Total: ${list.length}');
    b.writeln('Nouvo: $n | Chal: $ch | Kliyan: $k');
    b.writeln('Ak WhatsApp: $wa | Ak sit wèb: $web | San sit: ${list.length - web}');
    b.writeln('Revni total: \$${revenue.toStringAsFixed(2)}');
    b.writeln();

    for (final status in ['Nouvo', 'Chal', 'Kliyan']) {
      final items = list.where((p) => p.status == status).toList();
      if (items.isEmpty) continue;
      b.writeln('--- $status (${items.length}) ---');
      for (final p in items) {
        b.writeln('  [${p.id}] ${p.name} | ${p.category}');
        b.writeln('      Tel: ${p.phone} | Web: ${p.website}');
        b.writeln('      Adrès: ${p.address}');
        b.writeln();
      }
    }

    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/cnmfox_rapo_${now.millisecondsSinceEpoch}.txt';
    await File(path).writeAsString(b.toString());
    return path;
  }
}
