import 'dart:io';
import 'package:csv/csv.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../models/prospect.dart';
import 'storage.dart';

class CsvService {
  static const _headers = [
    'id', 'name', 'category', 'address', 'phone', 'website', 'maps_url',
    'rating', 'status', 'date', 'last_followup', 'notes', 'source',
    'package_offered', 'deal_value'
  ];

  static const _aliases = <String, List<String>>{
    'name': ['name', 'nom', 'business', 'title'],
    'category': ['category', 'categorie', 'type'],
    'address': ['address', 'adresse', 'zone', 'location'],
    'phone': ['phone', 'tel', 'whatsapp', 'mobile'],
    'website': ['website', 'site', 'web'],
    'maps_url': ['maps_url', 'maps', 'google_maps', 'lien'],
    'rating': ['rating', 'score'],
    'notes': ['notes', 'note', 'comment'],
    'status': ['status', 'estat'],
    'package_offered': ['package_offered', 'package', 'pake'],
    'deal_value': ['deal_value', 'deal', 'valeur'],
  };

  static Future<String> exportCsv(List<Prospect> list) async {
    final rows = <List<dynamic>>[_headers];
    for (final p in list) {
      final m = p.toJson();
      rows.add(_headers.map((h) => (m[h] ?? '').toString()).toList());
    }
    final csv = const ListToCsvConverter().convert(rows);
    final dir = await getApplicationDocumentsDirectory();
    final path =
        '${dir.path}/cnmfox_prospects_${DateTime.now().millisecondsSinceEpoch}.csv';
    await File(path).writeAsString('\uFEFF$csv');
    return path;
  }

  /// Retounen konbyen pwospek ki ajoute (doublon sote).
  static Future<int> importCsv() async {
    final picked = await FilePicker.platform
        .pickFiles(type: FileType.any);
    if (picked == null || picked.files.single.path == null) return 0;

    var content = await File(picked.files.single.path!).readAsString();
    content = content.replaceAll('\uFEFF', '').replaceAll('\r\n', '\n');
    final rows = const CsvToListConverter(eol: '\n', shouldParseNumbers: false)
        .convert(content);
    if (rows.isEmpty) return 0;

    final headers =
        rows.first.map((e) => e.toString().toLowerCase().trim()).toList();
    final cm = <String, int>{};
    _aliases.forEach((field, names) {
      int idx = headers.indexWhere((h) => names.contains(h));
      if (idx < 0) {
        idx = headers.indexWhere((h) => names.any((n) => h.contains(n)));
      }
      if (idx >= 0) cm[field] = idx;
    });
    if (cm['name'] == null) throw Exception('Pa gen kolòn "name" oswa "nom"');

    const okStatus = ['Nouvo', 'Chal', 'Kliyan'];
    final items = <Prospect>[];
    for (int i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isEmpty) continue;
      final name = _get(row, cm['name']);
      if (name.isEmpty) continue;
      final st = _get(row, cm['status']);
      items.add(Prospect(
        id: 0,
        name: name,
        category: _get(row, cm['category'], fb: 'Lòt'),
        address: _get(row, cm['address']),
        phone: _get(row, cm['phone']),
        website: _get(row, cm['website']),
        mapsUrl: _get(row, cm['maps_url']),
        rating: _get(row, cm['rating']),
        status: okStatus.contains(st) ? st : 'Nouvo',
        date: DateTime.now().toIso8601String().substring(0, 10),
        notes: _get(row, cm['notes']),
        source: 'CSV',
        packageOffered: _get(row, cm['package_offered']),
        dealValue: double.tryParse(_get(row, cm['deal_value'])) ?? 0,
      ));
    }
    return Storage.addMany(items);
  }

  static String _get(List row, int? idx, {String fb = ''}) {
    if (idx == null || idx >= row.length) return fb;
    final v = row[idx].toString().trim();
    return v.isEmpty ? fb : v;
  }
}
