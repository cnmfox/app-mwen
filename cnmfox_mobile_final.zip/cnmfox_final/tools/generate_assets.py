#!/usr/bin/env python3
"""Jenere icon ak splash. Bezwen: pip install Pillow"""
import os
from PIL import Image, ImageDraw, ImageFont

os.makedirs("assets/icon", exist_ok=True)
os.makedirs("assets/splash", exist_ok=True)
BLUE, WHITE = (0, 102, 204, 255), (255, 255, 255, 255)

def font(size):
    for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/System/Library/Fonts/Helvetica.ttc", "C:/Windows/Fonts/arialbd.ttf"]:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()

def center_text(d, size_px, text, f, fill, dy=0):
    b = d.textbbox((0, 0), text, font=f)
    w, h = b[2] - b[0], b[3] - b[1]
    d.text(((size_px - w) / 2 - b[0], (size_px - h) / 2 - b[1] + dy), text, font=f, fill=fill)

S = 1024
img = Image.new("RGBA", (S, S), BLUE)
d = ImageDraw.Draw(img)
d.ellipse([(S//2-380, S//2-380), (S//2+380, S//2+380)], outline=WHITE, width=40)
center_text(d, S, "CF", font(420), WHITE)
img.save("assets/icon/icon.png")

fg = Image.new("RGBA", (S, S), (0, 0, 0, 0))
center_text(ImageDraw.Draw(fg), S, "CF", font(300), WHITE)
fg.save("assets/icon/icon_foreground.png")

SP = 1152
sp = Image.new("RGBA", (SP, SP), (0, 0, 0, 0))
ds = ImageDraw.Draw(sp)
ds.ellipse([(SP//2-160, SP//2-260), (SP//2+160, SP//2+60)], outline=WHITE, width=12)
center_text(ds, SP, "CF", font(160), WHITE, dy=-100)
center_text(ds, SP, "cnmfox", font(90), WHITE, dy=200)
sp.save("assets/splash/splash.png")
print("OK")
