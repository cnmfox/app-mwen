#!/usr/bin/env python3
"""Ajoute INTERNET + queries (WhatsApp/https) nan AndroidManifest.xml, mete non app la."""
import re, sys
P = "android/app/src/main/AndroidManifest.xml"
try:
    s = open(P, encoding="utf-8").read()
except FileNotFoundError:
    sys.exit("Pa jwenn " + P + " — kouri 'flutter create .' dabò.")

if "android.permission.INTERNET" not in s:
    s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)

q = ('<intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>\n'
     '        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="whatsapp"/></intent>')
if 'android:scheme="whatsapp"' not in s:
    if "</queries>" in s:
        s = s.replace("</queries>", "    " + q + "\n    </queries>", 1)
    else:
        s = s.replace("</manifest>", "    <queries>\n        " + q + "\n    </queries>\n</manifest>", 1)

s = re.sub(r'android:label="[^"]*"', 'android:label="cnmfox"', s, count=1)
open(P, "w", encoding="utf-8").write(s)
print("✓ AndroidManifest.xml patché")
