# cnmfox_mobile v1.2 — APK pèsonèl (san backend, san login)

## Egzijans
- Flutter SDK enstale (flutter doctor dwe OK) + Android SDK
- Python 3 + Pillow (sèlman pou jenere icon): pip install Pillow

## Etap (nan dosye sa a)
1. flutter create --org com.cnmfox --project-name cnmfox_mobile .
2. python tools/patch_manifest.py
3. python tools/generate_assets.py        (assets/ deja jenere — opsyonèl)
4. flutter pub get
5. dart run flutter_launcher_icons
6. dart run flutter_native_splash:create
7. flutter build apk --release

APK: build/app/outputs/flutter-apk/app-release.apk
Enstale: adb install build/app/outputs/flutter-apk/app-release.apk
(oswa voye fichye a sou telefòn, louvri l, aktive "Install unknown apps")

## Premye itilizasyon
Paramèt → mete Apify token / Firecrawl key → Anrejistre.
Backup: Akèy → Enpòte/Ekspòte → Ekspòte CSV.
